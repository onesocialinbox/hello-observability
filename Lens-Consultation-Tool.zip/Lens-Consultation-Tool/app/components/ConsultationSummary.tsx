import { Button } from "@/components/ui/button"

type ConsultationSummaryProps = {
  prescription: any
  preferences: any
}

export default function ConsultationSummary({ prescription, preferences }: ConsultationSummaryProps) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold mb-4">Consultation Summary</h2>
      
      <div>
        <h3 className="text-lg font-semibold mb-2">Prescription</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <h4 className="font-medium">Right Eye (OD)</h4>
            <p>SPH: {prescription.od_sph}</p>
            <p>CYL: {prescription.od_cyl}</p>
            <p>Axis: {prescription.od_axis}</p>
          </div>
          <div>
            <h4 className="font-medium">Left Eye (OS)</h4>
            <p>SPH: {prescription.os_sph}</p>
            <p>CYL: {prescription.os_cyl}</p>
            <p>Axis: {prescription.os_axis}</p>
          </div>
        </div>
        <p className="mt-2">PD: {prescription.pd}</p>
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-2">Preferences</h3>
        <p>Computer Usage: {preferences.computerUsage}</p>
        <p>Sports Activities: {preferences.sportsActivities.join(', ') || 'None'}</p>
        <p>Driving Frequency: {preferences.drivingFrequency}</p>
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-2">Recommendations</h3>
        <p>Based on the patient's prescription and preferences, we recommend:</p>
        <ul className="list-disc list-inside">
          <li>High-index lenses for thinner and lighter glasses</li>
          <li>Anti-reflective coating to reduce glare from computer screens and while driving</li>
          <li>Photochromic lenses for outdoor activities</li>
          <li>Consider progressive lenses for seamless transition between distances</li>
        </ul>
      </div>

      <Button onClick={() => alert('Consultation completed!')}>Complete Consultation</Button>
    </div>
  )
}

