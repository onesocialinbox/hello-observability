'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

type PreferencesData = {
  computerUsage: string
  sportsActivities: string[]
  drivingFrequency: string
}

export default function PreferencesForm({ onSubmit }: { onSubmit: (data: PreferencesData) => void }) {
  const [formData, setFormData] = useState<PreferencesData>({
    computerUsage: '',
    sportsActivities: [],
    drivingFrequency: ''
  })

  const handleComputerUsageChange = (value: string) => {
    setFormData({ ...formData, computerUsage: value })
  }

  const handleSportsActivitiesChange = (activity: string) => {
    const updatedActivities = formData.sportsActivities.includes(activity)
      ? formData.sportsActivities.filter(a => a !== activity)
      : [...formData.sportsActivities, activity]
    setFormData({ ...formData, sportsActivities: updatedActivities })
  }

  const handleDrivingFrequencyChange = (value: string) => {
    setFormData({ ...formData, drivingFrequency: value })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <h2 className="text-2xl font-bold mb-4">Patient Preferences</h2>
      
      <div>
        <h3 className="text-lg font-semibold mb-2">Computer Usage</h3>
        <RadioGroup value={formData.computerUsage} onValueChange={handleComputerUsageChange}>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="low" id="computer-low" />
            <Label htmlFor="computer-low">Low (0-2 hours/day)</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="medium" id="computer-medium" />
            <Label htmlFor="computer-medium">Medium (3-5 hours/day)</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="high" id="computer-high" />
            <Label htmlFor="computer-high">High (6+ hours/day)</Label>
          </div>
        </RadioGroup>
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-2">Sports Activities</h3>
        <div className="space-y-2">
          {['Running', 'Swimming', 'Cycling', 'Team Sports', 'Other'].map((activity) => (
            <div key={activity} className="flex items-center space-x-2">
              <Checkbox
                id={`sport-${activity.toLowerCase()}`}
                checked={formData.sportsActivities.includes(activity)}
                onCheckedChange={() => handleSportsActivitiesChange(activity)}
              />
              <Label htmlFor={`sport-${activity.toLowerCase()}`}>{activity}</Label>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-2">Driving Frequency</h3>
        <RadioGroup value={formData.drivingFrequency} onValueChange={handleDrivingFrequencyChange}>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="rarely" id="driving-rarely" />
            <Label htmlFor="driving-rarely">Rarely</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="occasionally" id="driving-occasionally" />
            <Label htmlFor="driving-occasionally">Occasionally</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="frequently" id="driving-frequently" />
            <Label htmlFor="driving-frequently">Frequently</Label>
          </div>
        </RadioGroup>
      </div>

      <Button type="submit">Next: Summary</Button>
    </form>
  )
}

