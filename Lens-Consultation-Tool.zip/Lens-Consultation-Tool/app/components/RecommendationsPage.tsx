import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

type ConsultationData = {
  prescription: {
    od_sph: string
    od_cyl: string
    os_sph: string
    os_cyl: string
  }
  preferences: {
    computerUsage: boolean
    outdoorActivities: boolean
    nightDriving: boolean
    readingFrequently: boolean
    sunSensitivity: boolean
    contactLensWearer: boolean
    previouslyWorePrescription: boolean
    eyeStrain: boolean
  }
  insurance?: {
    firstName: string
    lastName: string
    dateOfBirth: string
    insuranceProvider: string
    memberId: string
  }
}

type PlanItem = {
  name: string
  description: string
}

type Plan = {
  name: string
  lensType: PlanItem
  lensMaterial: PlanItem
  coatings: PlanItem[]
  normalPrice: number
  insurancePrice: number
}

const plans: Plan[] = [
  {
    name: "Basic",
    lensType: {
      name: "Single Vision",
      description: "Corrects vision for a single distance, suitable for most basic prescriptions."
    },
    lensMaterial: {
      name: "CR-39 Plastic",
      description: "Standard plastic lenses, lightweight and suitable for mild prescriptions."
    },
    coatings: [
      {
        name: "Anti-Scratch",
        description: "Protects your lenses from everyday wear and tear, extending their lifespan."
      }
    ],
    normalPrice: 100,
    insurancePrice: 80
  },
  {
    name: "Good",
    lensType: {
      name: "Single Vision",
      description: "Corrects vision for a single distance, with improved materials and coatings."
    },
    lensMaterial: {
      name: "Polycarbonate",
      description: "Impact-resistant material, ideal for active lifestyles and children's eyewear."
    },
    coatings: [
      {
        name: "Anti-Scratch",
        description: "Protects your lenses from everyday wear and tear, extending their lifespan."
      },
      {
        name: "Anti-Reflective",
        description: "Reduces glare and eye strain, especially helpful for night driving and computer use."
      }
    ],
    normalPrice: 200,
    insurancePrice: 160
  },
  {
    name: "Better",
    lensType: {
      name: "Progressive",
      description: "Provides seamless transition between distance, intermediate, and near vision."
    },
    lensMaterial: {
      name: "High-Index Plastic",
      description: "Thinner and lighter than standard plastic, ideal for stronger prescriptions."
    },
    coatings: [
      {
        name: "Anti-Scratch",
        description: "Protects your lenses from everyday wear and tear, extending their lifespan."
      },
      {
        name: "Anti-Reflective",
        description: "Reduces glare and eye strain, especially helpful for night driving and computer use."
      },
      {
        name: "UV Protection",
        description: "Blocks harmful UV rays, protecting your eyes from sun damage."
      }
    ],
    normalPrice: 300,
    insurancePrice: 240
  },
  {
    name: "Best",
    lensType: {
      name: "Digital Progressive",
      description: "Advanced progressive lenses with wider fields of view and smoother transitions."
    },
    lensMaterial: {
      name: "Ultra High-Index Plastic",
      description: "The thinnest and lightest lens material available, perfect for strong prescriptions."
    },
    coatings: [
      {
        name: "Anti-Scratch",
        description: "Protects your lenses from everyday wear and tear, extending their lifespan."
      },
      {
        name: "Premium Anti-Reflective",
        description: "Superior glare reduction and clarity, with added smudge and water-resistant properties."
      },
      {
        name: "UV Protection",
        description: "Blocks harmful UV rays, protecting your eyes from sun damage."
      },
      {
        name: "Blue Light Filter",
        description: "Reduces exposure to blue light from digital devices, potentially reducing eye strain and sleep disruption."
      }
    ],
    normalPrice: 400,
    insurancePrice: 320
  }
]

export default function RecommendationsPage({ data }: { data: ConsultationData }) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold mb-4">Lens Recommendations</h2>
      
      <div className="space-y-6">
        {plans.map((plan) => (
          <Card key={plan.name} className={`${plan.name === 'Better' ? 'border-4 border-primary' : ''}`}>
            <CardHeader>
              <CardTitle>{plan.name} Plan</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold">Lens Type: {plan.lensType.name}</h3>
                <p className="text-sm text-muted-foreground">{plan.lensType.description}</p>
              </div>
              <div>
                <h3 className="font-semibold">Lens Material: {plan.lensMaterial.name}</h3>
                <p className="text-sm text-muted-foreground">{plan.lensMaterial.description}</p>
              </div>
              <div>
                <h3 className="font-semibold">Coatings:</h3>
                <ul className="list-disc list-inside">
                  {plan.coatings.map((coating) => (
                    <li key={coating.name}>
                      <span className="font-medium">{coating.name}</span>: {coating.description}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-semibold">Normal Price: ${plan.normalPrice}</p>
                  {data.insurance && (
                    <p className="font-semibold text-primary">With Insurance: ${plan.insurancePrice}</p>
                  )}
                </div>
                <Button>Select {plan.name} Plan</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-8">
        <h3 className="text-xl font-semibold mb-2">Personalized Recommendations</h3>
        <ul className="list-disc list-inside">
          {data.preferences.computerUsage && (
            <li>Consider adding a blue light filter coating for reduced eye strain during computer use.</li>
          )}
          {data.preferences.outdoorActivities && (
            <li>Photochromic lenses or prescription sunglasses might be beneficial for your outdoor activities.</li>
          )}
          {data.preferences.nightDriving && (
            <li>An anti-reflective coating can help reduce glare while driving at night.</li>
          )}
          {data.preferences.readingFrequently && (
            <li>Progressive lenses or reading glasses might be suitable for frequent reading.</li>
          )}
          {data.preferences.sunSensitivity && (
            <li>Consider photochromic lenses or a high-quality UV protection coating for your sun sensitivity.</li>
          )}
          {data.preferences.contactLensWearer && (
            <li>You might want to consider getting a pair of glasses as a backup for when you're not wearing contacts.</li>
          )}
          {data.preferences.previouslyWorePrescription && (
            <li>Since you've worn prescription glasses before, you might find it easier to adapt to new lenses.</li>
          )}
          {data.preferences.eyeStrain && (
            <li>To help with eye strain, consider lenses with anti-reflective coating and possibly a blue light filter.</li>
          )}
        </ul>
      </div>
    </div>
  )
}

