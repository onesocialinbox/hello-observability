'use client'

import { useState } from 'react'
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import PrescriptionForm from './PrescriptionForm'
import PreferencesForm from './PreferencesForm'
import ConsultationSummary from './ConsultationSummary'

type Step = 'prescription' | 'preferences' | 'summary'

export default function LensConsultationTool() {
  const [step, setStep] = useState<Step>('prescription')
  const [prescriptionData, setPrescriptionData] = useState({})
  const [preferencesData, setPreferencesData] = useState({})

  const handlePrescriptionSubmit = (data: any) => {
    setPrescriptionData(data)
    setStep('preferences')
  }

  const handlePreferencesSubmit = (data: any) => {
    setPreferencesData(data)
    setStep('summary')
  }

  const handleBack = () => {
    if (step === 'preferences') setStep('prescription')
    if (step === 'summary') setStep('preferences')
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardContent className="p-6">
        {step === 'prescription' && <PrescriptionForm onSubmit={handlePrescriptionSubmit} />}
        {step === 'preferences' && <PreferencesForm onSubmit={handlePreferencesSubmit} />}
        {step === 'summary' && <ConsultationSummary prescription={prescriptionData} preferences={preferencesData} />}
        
        {step !== 'prescription' && (
          <Button onClick={handleBack} className="mt-4">
            Back
          </Button>
        )}
      </CardContent>
    </Card>
  )
}

