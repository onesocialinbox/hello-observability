import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

type ConsultationData = {
  prescription: {
    od_sph: string
    od_cyl: string
    os_sph: string
    os_cyl: string
  }
  preferences: {
    computerUsage: boolean
    outdoorActivities: boolean
    nightDriving: boolean
    readingFrequently: boolean
  }
  insurance: {
    firstName: string
    lastName: string
    dateOfBirth: string
    insuranceProvider: string
    memberId: string
  }
}

type Plan = {
  name: string
  lensType: string
  lensMaterial: string
  coatings: string[]
  price: number
}

const plans: Plan[] = [
  {
    name: "Basic",
    lensType: "Single Vision",
    lensMaterial: "CR-39 Plastic",
    coatings: ["Anti-Scratch"],
    price: 100
  },
  {
    name: "Good",
    lensType: "Single Vision",
    lensMaterial: "Polycarbonate",
    coatings: ["Anti-Scratch", "Anti-Reflective"],
    price: 200
  },
  {
    name: "Better",
    lensType: "Progressive",
    lensMaterial: "High-Index Plastic",
    coatings: ["Anti-Scratch", "Anti-Reflective", "UV Protection"],
    price: 300
  },
  {
    name: "Best",
    lensType: "Digital Progressive",
    lensMaterial: "Ultra High-Index Plastic",
    coatings: ["Anti-Scratch", "Premium Anti-Reflective", "UV Protection", "Blue Light Filter"],
    price: 400
  }
]

export default function RecommendationsPage({ data }: { data: ConsultationData }) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold mb-4">Lens Recommendations</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {plans.map((plan) => (
          <Card key={plan.name}>
            <CardHeader>
              <CardTitle>{plan.name} Plan</CardTitle>
            </CardHeader>
            <CardContent>
              <p><strong>Lens Type:</strong> {plan.lensType}</p>
              <p><strong>Lens Material:</strong> {plan.lensMaterial}</p>
              <p><strong>Coatings:</strong> {plan.coatings.join(", ")}</p>
              <p><strong>Price:</strong> ${plan.price}</p>
              <Button className="mt-4">Select {plan.name} Plan</Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-8">
        <h3 className="text-xl font-semibold mb-2">Personalized Recommendations</h3>
        <ul className="list-disc list-inside">
          {data.preferences.computerUsage && (
            <li>Consider adding a blue light filter coating for reduced eye strain during computer use.</li>
          )}
          {data.preferences.outdoorActivities && (
            <li>Photochromic lenses or prescription sunglasses might be beneficial for your outdoor activities.</li>
          )}
          {data.preferences.nightDriving && (
            <li>An anti-reflective coating can help reduce glare while driving at night.</li>
          )}
          {data.preferences.readingFrequently && (
            <li>Progressive lenses or reading glasses might be suitable for frequent reading.</li>
          )}
        </ul>
      </div>
    </div>
  )
}

