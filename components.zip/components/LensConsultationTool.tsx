"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
// import ConsultationForm from "'./ConsultationForm'"
// import RecommendationsPage from "'./RecommendationsPage'"
import ConsultationForm from "./ConsultationForm"
import RecommendationsPage from "./RecommendationsPage"

type ConsultationData = {
  prescription: {
    od_sph: string
    od_cyl: string
    os_sph: string
    os_cyl: string
  }
  preferences: {
    computerUsage: boolean
    outdoorActivities: boolean
    nightDriving: boolean
    readingFrequently: boolean
    sunSensitivity: boolean
    contactLensWearer: boolean
    previouslyWorePrescription: boolean
    eyeStrain: boolean
  }
  insurance?: {
    firstName: string
    lastName: string
    dateOfBirth: string
    insuranceProvider: string
    memberId: string
  }
}

export default function LensConsultationTool() {
  const [step, setStep] = useState<"'form'" | "'recommendations'">("'form'")
  const [consultationData, setConsultationData] = useState<ConsultationData | null>(null)

  const handleFormSubmit = (data: ConsultationData) => {
    setConsultationData(data)
    setStep("'recommendations'")
  }

  const handleBack = () => {
    setStep("'form'")
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardContent className="p-6">
        {step === "'form'" && <ConsultationForm onSubmit={handleFormSubmit} />}
        {step === "'recommendations'" && consultationData && (
          <>
            <RecommendationsPage data={consultationData} />
            <Button onClick={handleBack} className="mt-4">
              Back to Form
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  )
}

