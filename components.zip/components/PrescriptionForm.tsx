"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

type PrescriptionData = {
  od_sph: string
  od_cyl: string
  od_axis: string
  os_sph: string
  os_cyl: string
  os_axis: string
  pd: string
}

export default function PrescriptionForm({ onSubmit }: { onSubmit: (data: PrescriptionData) => void }) {
  const [formData, setFormData] = useState<PrescriptionData>({
    od_sph: "", od_cyl: "", od_axis: "",
    os_sph: "", os_cyl: "", os_axis: "",
    pd: ""
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <h2 className="text-2xl font-bold mb-4">Prescription Details</h2>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <h3 className="text-lg font-semibold mb-2">Right Eye (OD)</h3>
          <div className="space-y-2">
            <Label htmlFor="od_sph">SPH</Label>
            <Input id="od_sph" name="od_sph" value={formData.od_sph} onChange={handleChange} required />
            
            <Label htmlFor="od_cyl">CYL</Label>
            <Input id="od_cyl" name="od_cyl" value={formData.od_cyl} onChange={handleChange} required />
            
            <Label htmlFor="od_axis">Axis</Label>
            <Input id="od_axis" name="od_axis" value={formData.od_axis} onChange={handleChange} required />
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-semibold mb-2">Left Eye (OS)</h3>
          <div className="space-y-2">
            <Label htmlFor="os_sph">SPH</Label>
            <Input id="os_sph" name="os_sph" value={formData.os_sph} onChange={handleChange} required />
            
            <Label htmlFor="os_cyl">CYL</Label>
            <Input id="os_cyl" name="os_cyl" value={formData.os_cyl} onChange={handleChange} required />
            
            <Label htmlFor="os_axis">Axis</Label>
            <Input id="os_axis" name="os_axis" value={formData.os_axis} onChange={handleChange} required />
          </div>
        </div>
      </div>
      
      <div>
        <Label htmlFor="pd">Pupillary Distance (PD)</Label>
        <Input id="pd" name="pd" value={formData.pd} onChange={handleChange} required />
      </div>

      <Button type="submit">Next: Preferences</Button>
    </form>
  )
}

