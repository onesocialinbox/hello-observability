"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"

type ConsultationData = {
  prescription: {
    od_sph: string
    od_cyl: string
    os_sph: string
    os_cyl: string
  }
  preferences: {
    computerUsage: boolean
    outdoorActivities: boolean
    nightDriving: boolean
    readingFrequently: boolean
    sunSensitivity: boolean
    contactLensWearer: boolean
    previouslyWorePrescription: boolean
    eyeStrain: boolean
  }
  insurance?: {
    firstName: string
    lastName: string
    dateOfBirth: string
    insuranceProvider: string
    memberId: string
  }
}

export default function ConsultationForm({ onSubmit }: { onSubmit: (data: ConsultationData) => void }) {
  const [formData, setFormData] = useState<ConsultationData>({
    prescription: { od_sph: "", od_cyl: "", os_sph: "", os_cyl: "" },
    preferences: {
      computerUsage: false,
      outdoorActivities: false,
      nightDriving: false,
      readingFrequently: false,
      sunSensitivity: false,
      contactLensWearer: false,
      previouslyWorePrescription: false,
      eyeStrain: false
    },
  })
  const [includeInsurance, setIncludeInsurance] = useState(false)

  const handlePrescriptionChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      prescription: { ...formData.prescription, [e.target.name]: e.target.value }
    })
  }

  const handlePreferenceChange = (name: string, checked: boolean) => {
    setFormData({
      ...formData,
      preferences: { ...formData.preferences, [name]: checked }
    })
  }

  const handleInsuranceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      insurance: { ...formData.insurance, [e.target.name]: e.target.value }
    } as ConsultationData)
  }

  const handleInsuranceProviderChange = (value: string) => {
    setFormData({
      ...formData,
      insurance: { ...formData.insurance, insuranceProvider: value }
    } as ConsultationData)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(includeInsurance ? formData : { ...formData, insurance: undefined })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <Card>
        <CardContent className="pt-6">
          <h2 className="text-2xl font-bold mb-4">Prescription Details</h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="od_sph">OD SPH</Label>
              <Input id="od_sph" name="od_sph" value={formData.prescription.od_sph} onChange={handlePrescriptionChange} required />
            </div>
            <div>
              <Label htmlFor="od_cyl">OD CYL</Label>
              <Input id="od_cyl" name="od_cyl" value={formData.prescription.od_cyl} onChange={handlePrescriptionChange} required />
            </div>
            <div>
              <Label htmlFor="os_sph">OS SPH</Label>
              <Input id="os_sph" name="os_sph" value={formData.prescription.os_sph} onChange={handlePrescriptionChange} required />
            </div>
            <div>
              <Label htmlFor="os_cyl">OS CYL</Label>
              <Input id="os_cyl" name="os_cyl" value={formData.prescription.os_cyl} onChange={handlePrescriptionChange} required />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6">
          <h2 className="text-2xl font-bold mb-4">Preferences</h2>
          <div className="space-y-4">
            {Object.entries(formData.preferences).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between">
                <Label htmlFor={key}>{key.replace(/([A-Z])/g, "' $1'").replace(/^./, str => str.toUpperCase())}</Label>
                <Switch
                  id={key}
                  checked={value}
                  onCheckedChange={(checked) => handlePreferenceChange(key, checked)}
                />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">Insurance Details (Optional)</h2>
            <Switch
              id="includeInsurance"
              checked={includeInsurance}
              onCheckedChange={setIncludeInsurance}
            />
          </div>
          {includeInsurance && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">First Name</Label>
                <Input id="firstName" name="firstName" value={formData.insurance?.firstName || ""} onChange={handleInsuranceChange} required={includeInsurance} />
              </div>
              <div>
                <Label htmlFor="lastName">Last Name</Label>
                <Input id="lastName" name="lastName" value={formData.insurance?.lastName || ""} onChange={handleInsuranceChange} required={includeInsurance} />
              </div>
              <div>
                <Label htmlFor="dateOfBirth">Date of Birth</Label>
                <Input id="dateOfBirth" name="dateOfBirth" type="date" value={formData.insurance?.dateOfBirth || ""} onChange={handleInsuranceChange} required={includeInsurance} />
              </div>
              <div>
                <Label htmlFor="insuranceProvider">Insurance Provider</Label>
                <Select onValueChange={handleInsuranceProviderChange} value={formData.insurance?.insuranceProvider || ""}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select provider" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="provider1">Provider 1</SelectItem>
                    <SelectItem value="provider2">Provider 2</SelectItem>
                    <SelectItem value="provider3">Provider 3</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="memberId">Member ID</Label>
                <Input id="memberId" name="memberId" value={formData.insurance?.memberId || ""} onChange={handleInsuranceChange} required={includeInsurance} />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Button type="submit">Submit and View Recommendations</Button>
    </form>
  )
}

